## NOTES ##

This example currently does not work as intended. 

## Variable-length Sequence Memory Evolution ##

`evolve.py` Generates networks to reproduce a variable-length sequence of binary inputs.